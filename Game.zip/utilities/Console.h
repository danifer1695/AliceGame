#ifndef CONSOLE_H
#define CONSOLE_H

#define PAUSE Console::pause()

#include "Logger.h"
#include <Windows.h>
#include <iostream>
#include <memory>
#include <string>

class Console {
	
private:

	const int screen_width = 128; //In number of characters
	const int screen_height = 48;
	const int buffer_size = screen_width * screen_height; //The total amount of chars the buffer can hold
	
	
	HANDLE m_hConsole; 			/*Handle (h) to main (m) output console, will let us manipulate the console's properties, such as changing text colors, 
									clearing the screen, or setting cursor positions*/
	HWND m_hConsoleWindow; 		//Handle to a window, will allow us to resize, move or minimize it
	RECT m_ConsoleWindowRect; 	//Windows struct that defines a rectangle using 4 ints. We will use it to control the window size
	DWORD m_bytes_written;
	
	std::unique_ptr<wchar_t[]> m_pScreen; //Screen buffer contents. A unique pointer to an array of wide characters

public:
	
	Console();
	~Console() = default;
	
	void Write(int x, int y, const std::wstring &text, Logger::Color color = WHITE);
	void Draw();
	void clear_buffer();
	void pause();
	bool show_console_cursor(bool show);
};

#endif