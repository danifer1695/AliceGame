#include "Console.h"


//******************************************************************************************************************************
// Constructor
//******************************************************************************************************************************

	Console::Console()
		:m_pScreen{nullptr}{
		
		//We initialize the screen buffer
		m_pScreen = std::make_unique <wchar_t[]>(buffer_size);
		
		/*We create our own console window. if we use cmd's console we might lack permissions to manipulate
		its position, size and so on*/
		
		//FreeConsole(); //FreeConsole detaches the program from the default cmd console so we can use a new one
		//if(!AllocConsole()){
		//	throw std::runtime_error("Failed to allocate new console. Error: " + std::to_string(GetLastError()));
		//}
		
		//Get handle to the console window
		m_hConsoleWindow = GetConsoleWindow();
		if (m_hConsoleWindow == NULL) {
			throw std::runtime_error("GetConsoleWindow() returned NULL. Error: " + std::to_string(GetLastError()));
		}
		
		//Get window rect, from m_hConsoleWindow stored in m_ConsoleWindowRect, and check if successful
		if(!GetWindowRect(m_hConsoleWindow, &m_ConsoleWindowRect))
			throw std::runtime_error("Couldn't get window rect when creating the console.");
		
		//Get the font size and handle to standard output
		//We will use this info to calculate the size of the console screen
		
		HANDLE std_handle = GetStdHandle(STD_OUTPUT_HANDLE);
		if (std_handle == INVALID_HANDLE_VALUE || std_handle == NULL) 
			throw std::runtime_error("Invalid standard output handle: " + std::to_string(GetLastError()));

		CONSOLE_FONT_INFO font_info;
		if(!GetCurrentConsoleFont(std_handle, false, &font_info))
			throw std::runtime_error("Couldn't get the console font when creating the console.");
		
		COORD font_size = GetConsoleFontSize(std_handle, font_info.nFont);
		if (font_size.X == 0 || font_size.Y == 0) 
			throw std::runtime_error("Invalid console font size. Error: " + std::to_string(GetLastError()));
		
		
		/*Now we calculate the size of the actual screen (in pixels) we will be creating by multiplying the amount 
		of characters by the pixel size of our font for each axis. */
		int actual_screen_x = screen_width * font_size.X;
		int actual_screen_y = screen_height * font_size.Y;
		
		/*We want to position the window in the center of the screen so for that we will use GetSystemMetrics(SM_CXSCREEN / SM_CYSCREEN)
		which returns out screen size, divide it by two and subtract our actual_screen size also divided by half*/
		int pos_x = GetSystemMetrics(SM_CXSCREEN) / 2 - (actual_screen_x / 2);
		int pos_y = GetSystemMetrics(SM_CYSCREEN) / 2 - (actual_screen_y / 2);
		
		//Set the size and position of the window
		if(!MoveWindow(m_hConsoleWindow, pos_x, pos_y, actual_screen_x, actual_screen_y, true))
			throw std::runtime_error("Couldn't set and move the console window.");
		
		//We clear the screen buffer
		clear_buffer();
		
		/*Create the screen buffer. This creates a new hidden buffer where we can edit the 
		output without being shown, until we activate it.*/
		m_hConsole = CreateConsoleScreenBuffer(
			GENERIC_READ | GENERIC_WRITE, //Allow read and write access
			0, 							  //No special sharing options
			NULL, 						  //No security attributes(defalt)
			CONSOLE_TEXTMODE_BUFFER, 	  //Creating a text-mode console buffer
			NULL						  //No additional attributes
		); 						  
		
		if(!m_hConsole)
			throw std::runtime_error("Couldn't create the console screen buffer");
		
		//Set the buffer to be active
		if(!SetConsoleActiveScreenBuffer(m_hConsole))
			throw std::runtime_error("Coultn't set the active screen buffer");
		
		//Hide the cursor
		if(!show_console_cursor(false))
			throw std::runtime_error("Couldn't hide the console cursor");
	}

//******************************************************************************************************************************
// clear_buffer()
//******************************************************************************************************************************
	
	void Console::clear_buffer(){
		
		//We set all values in the buffer to empty space
		for(int i = 0; i < buffer_size; i++)
			m_pScreen[i] = L'0'; //L just turns a char literal to a wchar_t;
		
		RESET_TEXT_COLOR(m_hConsole); //Macro we created back in the Logger class
	}
	
//******************************************************************************************************************************
// bool show_console_cursor()
//******************************************************************************************************************************
	
	
	bool Console::show_console_cursor(bool show){
		
		CONSOLE_CURSOR_INFO cursor_info;
		
		if(!GetConsoleCursorInfo(m_hConsole, &cursor_info)){
			GAME_ERROR("Couldn't get cursor info.");
			return false;
		}
		
		cursor_info.bVisible = show;
		
		return SetConsoleCursorInfo(m_hConsole, &cursor_info);
	}
	
//******************************************************************************************************************************
// void Write()
//******************************************************************************************************************************
	
	/*Writes a wide string (std::wstring) at a given (x, y) position in the console buffer.
	
	This does not show it on the console, since we are storing the info on a hidden buffer (accesible through m_hConsole).
	To display it, we will later call Draw().
	
	In other words, this sets up the contents we will want to show in a back room before sending it to the stage (the console window)*/
	
	void Console::Write(int x, int y, const std::wstring &text, Logger::Color color){
		SET_TEXT_COLOR(color, m_hConsole);
		
		int pos = (y * screen_width) + x; /* pos is the position index we want. To find it, first we multiply "y" times the number of
											characters per row (y * screen_width) to go down "y" number of rows - so y*2 puts us at
											row number 2 and so son; then we add "x" to move to the desired column.
											Remember- character position here is not a grid, its a straight line wrapping around in 
											rows*/
		swprintf( 				//Composes a wide c-style string (wstring)
			&m_pScreen[pos], 	//Points at where the text should start
			buffer_size, 		//Length of the string produced
			text.c_str()		//Formatting: converts to a c-style wide string
			);
			
		
	}
	
//******************************************************************************************************************************
// void Draw()
//******************************************************************************************************************************

	void Console::Draw(){
		
		//This function writes the console buffer (m_pScreen) to the console window.
		//The goal is to update the visible text on the screen.
		WriteConsoleOutputCharacterW(
			m_hConsole, 
			m_pScreen.get(),			//m_pScreen is a unique pointer, and WriteConsoleOutputCharacter() requires a C-style raw pointer, so we get it through .get()
			buffer_size,				//
			{0,0},						//The coordinates of where to start writing in the console window - top, left
			&m_bytes_written			//Address of a DWORD variable. There, the function will store how many characters were actually written. 
			);
	}
	
	
//******************************************************************************************************************************
// void pause()
//******************************************************************************************************************************
	
	void Console::pause(){
		
		std::cout << "Program paused. Press any key to continue" << std::endl;
		char temp{};
		std::cin >> temp;
	}