#ifndef USE_DATABASE_H
#define USE_DATABASE_H

#include <unordered_map>
#include <string>
#include <functional>

#include "Events.h"
	
	using KeyType = std::pair<std::string, std::string>;
	using FunctionType = std::function<void()>;
	
	//Custom hash function for std::pair
	struct PairHash {
		std::size_t operator()(const KeyType& key) const{
			return std::hash<std::string>{}(key.first)^(std::hash<std::string>{}(key.second) << 1);
		}
	}
	
	static std::unordered_map<KeyType, FunctionType, PairHash> use_database = {
		
		{"Cheshire_01", "Chesire: Hello little one. It looks like you've found yourself in quite the pickle.\nAlice: Oh dear Mr.Pussycat, thank goodness you came. I am indeed in trouble. Yes indeed."},
		{"Guard_01", "Guard: Oi! What are you doing here, you cheeky devil! Go on then! Back to the cell with you!"}
	};

#endif